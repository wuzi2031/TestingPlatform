# ExecutePlatform
自动化执行lib

## 使用步骤：
* 测试平台的服务端安装server包，执行机安装client包
* server端 python setup.py install安装即可
* client端：
  * python setup.py install安装
  * 拷贝plat.py与setting.py到本地
  * 修改setting.py里面的服务器和文件地址
  * 运行python plat.py -start开启服务，如果要重新启动先python plat.py -stop
### 依赖：
* mysqlclient
* pika
* pymysql
* requests
* celery
* 配置appium环境
* 配置selenium环境
* java环境
* 安卓环境