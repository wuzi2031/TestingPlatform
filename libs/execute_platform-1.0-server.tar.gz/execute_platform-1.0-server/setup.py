from setuptools import find_packages
from setuptools import setup

setup(name='execute_platform',
      version='1.0-server',
      author='wzm',
      packages=find_packages(),
      platforms="mac",
      # install_requires=['requests']
      )
