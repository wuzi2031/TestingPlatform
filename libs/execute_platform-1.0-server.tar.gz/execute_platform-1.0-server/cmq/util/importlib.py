import importlib


def dynamic_import_class(imp_module, imp_class):
    """
    动态加载class
    :param imp_module:
    :param imp_class:
    :return:
    """
    ip_module = importlib.import_module('.', imp_module)
    ip_module_cls = getattr(ip_module, imp_class)
    return ip_module_cls


def dynamic_import_module(imp_module):
    """
    动态加载模块
    :param imp_module: 路径 x.x.x
    :return:
    """
    ip_module = importlib.import_module('.', imp_module)
    return ip_module
