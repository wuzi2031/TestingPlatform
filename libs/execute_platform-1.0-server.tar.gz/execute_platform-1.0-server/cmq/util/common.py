import os
import socket


def gethost():
    # 获取本机电脑名
    myname = socket.getfqdn(socket.gethostname())
    # 获取本机ip
    myaddr = socket.gethostbyname(myname)
    host = {}
    host["name"] = myname
    host["ip"] = myaddr
    return host


def kill_process_by_name(name):
    cmd = "ps -e | grep %s" % name
    f = os.popen(cmd)
    txt = f.readlines()
    if len(txt) == 0:
        print
        "no process \"%s\"!!" % name
        return
    else:

        for line in txt:
            colum = line.split()
            pid = colum[0]
            cmd = "kill -9 %d" % int(pid)
            rc = os.system(cmd)
            if rc == 0:
                print
                "exec \"%s\" success!!" % cmd
            else:

                print
                "exec \"%s\" failed!!" % cmd
    return


def kill_process_by_port(name, port):
    cmd = "ps -e | grep %s" % name
    f = os.popen(cmd)
    txt = f.readlines()
    if len(txt) == 0:
        print
        "no process \"%s\"!!" % name
        return
    else:

        for line in txt:
            if '-p ' + str(port) in line:
                colum = line.split()
                pid = colum[0]
                cmd = "kill -9 %d" % int(pid)
                rc = os.system(cmd)
                if rc == 0:
                    print
                    "exec \"%s\" success!!" % cmd
                else:

                    print
                    "exec \"%s\" failed!!" % cmd
    return
