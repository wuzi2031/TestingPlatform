import os


def exists(path):
    return os.path.exists(path)


def create(dirs):
    if (not exists(dirs)):
        os.makedirs(dirs, exist_ok=True)


def remove_file(file_path):
    if (exists(file_path)):
        os.remove(file_path)


def remove_dir(dirs):
    if (exists(dirs)):
        os.rmdir(dirs)


if __name__ == '__main__':
    # os.chmod('/home', 777)
    # os.popen('sudo chmod 777 /home')
    create(r'/home/apk')
