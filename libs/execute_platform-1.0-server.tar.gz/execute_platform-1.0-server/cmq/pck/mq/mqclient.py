import pika

from cmq.pck.setting import BROKER_CONFIG


class Customer:
    def __init__(self, exchange, routing_keys, callback):
        self.exchange = exchange
        self.routing_keys = routing_keys
        self.callback = callback
        credentials = pika.PlainCredentials(BROKER_CONFIG["user"], BROKER_CONFIG["password"])
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(
            host=BROKER_CONFIG["address"], port=BROKER_CONFIG["port"], credentials=credentials))
        self.channel = self.connection.channel()
        self.channel.basic_qos(0, 1, False)
        self.channel.exchange_declare(exchange=exchange, exchange_type='topic')
        result = self.channel.queue_declare(exclusive=True)
        self.channel.basic_qos(prefetch_count=1)
        queue_name = result.method.queue
        for routing_key in routing_keys:
            self.channel.queue_bind(exchange=exchange, queue=queue_name, routing_key=routing_key)

        print(' [*] Waiting for logs. To exit press CTRL+C')
        # no_ack=Fales:表示消费完以后不自动把状态通知rabbitmq
        self.channel.basic_consume(callback, queue=queue_name, no_ack=False)

    def receive(self):
        """
        接收消息
        """
        self.channel.start_consuming()

    # def async_receive(self):
    #     with ProcessPoolExecutor(max_workers=1) as p:
    #         p.submit(self.receive)

    def disconnect(self):
        self.channel.stop_consuming()
        self.connection.close()


def callback(ch, method, properties, body):
    print(" [x] %r:%r" % (method.routing_key, body))
    ch.basic_ack(delivery_tag=method.delivery_tag)


if __name__ == "__main__":
    c = Customer("test_plat_topic", ["task.#"], callback)
    # c.async_receive()
    c.receive()
    print('hahaha')
