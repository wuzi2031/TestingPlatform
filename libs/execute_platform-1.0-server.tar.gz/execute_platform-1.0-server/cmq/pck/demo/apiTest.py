import random
import time

from cmq.tlib.request.httpRequests import Http, Method

from cmq.pacakage.tlib.base import BaseCase


class ApiTest(BaseCase):
    def before(self):
        pass

    def after(self):
        self.http.close()

    def random_32(self):
        seed = "1234567890abcdef"
        sa = []
        for i in range(32):
            sa.append(random.choice(seed))
        salt = ''.join(sa)
        return salt

    def random_24(self):
        seed = "1234567890"
        sa = []
        for i in range(24):
            sa.append(random.choice(seed))
        salt = ''.join(sa)
        return salt

    def test_login(self):
        i = 1
        while (i > 0):
            time.sleep(2)
            header = {'Content-Type': 'application/json',
                      'kry-api-brand-id': '59723'}
            self.http = Http(header=header, timeout=3)
            tradeUuid = self.random_32()  # 'f13d5f6092a04f61bda70cc547965099'
            uuid = self.random_32()  # '743cd426cdb447dc8fefe3e2c8b84346'
            tradeNo = self.random_24()  # '101180803135946517000809'
            url = 'https://calm4.keruyun.com/CalmRouter/v1/trade/submit'
            body = {
                "appType": "5",
                "brandID": 59723,
                "content": {
                    "brandIdenty": 59723,
                    "businessType": 1,
                    "changed": True,
                    "clientCreateTime": 1533276067659,
                    "clientUpdateTime": 1533276067659,
                    "creatorId": 120682522773404672,
                    "creatorName": "袁娟",
                    "deliveryType": 1,
                    "deviceIdenty": "cc:b8:a8:93:0d:9c",
                    "domainType": 1,
                    "privilegeAmount": 0.0,
                    "saleAmount": 13.0,
                    "shopIdenty": 810181113,
                    "skuKindCount": 1,
                    "source": 10,
                    "sourceChild": 1,
                    "statusFlag": 1,
                    "tradeAmount": 13.0,
                    "tradeAmountBefore": 13.0,
                    "tradeDeposit": {
                        "brandIdenty": 59723,
                        "changed": True,
                        "depositPay": 1,
                        "shopIdenty": 810181113,
                        "statusFlag": 1,
                        "tradeUuid": tradeUuid,
                        "uuid": uuid
                    },
                    "tradeExtra": {
                        "brandIdenty": 59723,
                        "changed": True,
                        "clientCreateTime": 1533276067646,
                        "clientUpdateTime": 1533276067646,
                        "creatorId": 120682522773404672,
                        "creatorName": "袁娟",
                        "deliveryPlatform": 1,
                        "deviceIdenty": "cc:b8:a8:93:0d:9c",
                        "shopIdenty": 810181113,
                        "statusFlag": 1,
                        "tradeUuid": tradeUuid,
                        "updatorId": 120682522773404672,
                        "updatorName": "袁娟",
                        "uuid": uuid
                    },
                    "tradeExtras": [
                        {
                            "brandIdenty": 59723,
                            "changed": True,
                            "clientCreateTime": 1533276067646,
                            "clientUpdateTime": 1533276067646,
                            "creatorId": 120682522773404672,
                            "creatorName": "袁娟",
                            "deliveryPlatform": 1,
                            "deviceIdenty": "cc:b8:a8:93:0d:9c",
                            "shopIdenty": 810181113,
                            "statusFlag": 1,
                            "tradeUuid": tradeUuid,
                            "updatorId": 120682522773404672,
                            "updatorName": "袁娟",
                            "uuid": uuid
                        }
                    ],
                    "tradeItemExtraDinners": [],
                    "tradeItemExtras": [],
                    "tradeItems": [
                        {
                            "actualAmount": 12.0,
                            "amount": 12.0,
                            "brandIdenty": 59723,
                            "changed": True,
                            "clientCreateTime": 1533276067652,
                            "clientUpdateTime": 1533276067652,
                            "creatorId": 120682522773404672,
                            "creatorName": "袁娟",
                            "deviceIdenty": "cc:b8:a8:93:0d:9c",
                            "enableWholePrivilege": 1,
                            "feedsAmount": 0,
                            "guestPrinted": 2,
                            "isChangePrice": 2,
                            "issueStatus": 2,
                            "itemSource": 1,
                            "price": 12.0,
                            "propertyAmount": 0,
                            "quantity": 1,
                            "saleType": 2,
                            "shopIdenty": 810181113,
                            "skuId": 120686618654144512,
                            "skuName": "青椒肉丝",
                            "skuUuid": "e9504cd1ac1a485bb791ce7c175f2001",
                            "sort": 0,
                            "statusFlag": 1,
                            "tradeUuid": tradeUuid,
                            "type": 0,
                            "unitName": "克",
                            "updatorId": 120682522773404672,
                            "updatorName": "袁娟",
                            "uuid": uuid
                        }
                    ],
                    "tradeNo": tradeNo,
                    "tradePayForm": 1,
                    "tradePayStatus": 1,
                    "tradePeopleCount": 1,
                    "tradeStatus": 3,
                    "tradeTime": 1533275986516,
                    "tradeType": 1,
                    "updatorId": 120682522773404672,
                    "updatorName": "袁娟",
                    "uuid": uuid
                },
                "deviceID": "cc:b8:a8:93:0d:9c",
                "nationInfos": [
                    {}
                ],
                "opVersionUUID": "cb1a4dc6ec0b4d9a8fd87959afe898f7",
                "shopID": 810181113,
                "systemType": "android",
                "timeZone": "Etc/GMT+8",
                "versionCode": "2110081500",
                "versionName": "8.15.0"
            }
            try:
                re = self.http.request(url=url,
                                       method=Method.POST,
                                       data=body)
                print(re)
            except Exception as e:
                print(e)

            # http1 = Http(header=header, timeout=3)
            # http1.set_cookies()
            # url1 = 'https://weixin.keruyun.com/takeaway/subOrder.json?shopId=810181113'
            # body1 = {
            #     "shopId": "810181113",
            #     "useDiscount": 0,
            #     "memo": "",
            #     "needPayPrice": 15,
            #     "payMethod": "1",
            #     "invoice": "",
            #     "consumePassword": "",
            #     "taxIdentyNo": "",
            #     "sourceChild": 32,
            #     "integral": 0,
            #     "singleDishInfos": [{
            #         "num": 1,
            #         "price": 15,
            #         "ingredientIds": [],
            #         "propertyIds": [],
            #         "dishId": "120686618939357184",
            #         "shopId": "810181113",
            #         "brandDishId": "120686618859665408",
            #         "priType": None,
            #         "priId": None
            #     }],
            #     "multiDishInfos": [],
            #     "name": "测试",
            #     "mobile": "15882135535",
            #     "sex": 1,
            #     "orderType": "WM",
            #     "address": "四川省政府(成都市锦江区督院街30号)123",
            #     "memberAddressId": "122035354034386944",
            #     "sendAreaId": "0",
            #     "toShopFlag": False,
            #     "latitude": "30.656956",
            #     "longitude": "104.082779",
            #     "time": "2018-08-03 尽快送达",
            #     "multiPriId": 0
            # }
            # try:
            #     re1 = http1.request(url=url1,
            #                            method=Method.POST,
            #                            data=body1)
            #     print(re1)
            # except Exception as e:
            #     print(e)
            i = i - 1
            self.http.close()
