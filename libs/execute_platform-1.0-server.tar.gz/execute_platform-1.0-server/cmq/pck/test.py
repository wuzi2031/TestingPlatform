from cmq.pacakage.tasks import message_receive

message_receive.delay()
