from __future__ import absolute_import

import json
import os
import sys

from cmq.pck.util.adb import AdbTools

from cmq.pck import app
from cmq.pck.mq.mqclient import Customer
from cmq.pck.tlib.request.httpRequests import Http, Method

cwd = os.path.dirname(__file__)
package_path = os.path.join(cwd, "../")
sys.path.append(package_path)


@app.task(ignore_result=True)  # 设置ignore_rsult可以忽略任务结果
def device_check():
    adbTools = AdbTools()
    devices_que = adbTools.get_devices()
    print(devices_que)
    header = {'Content-Type': 'application/json'}
    http = Http(header=header, timeout=3)
    url = 'http://127.0.0.1:8000/device_sync'
    body = devices_que

    re = http.request(url=url,
                      method=Method.POST,
                      data=body)
    http.close()
    print(re)
    # 将结果传回服务器


def callback(ch, method, properties, body):
    print(" [x] %r:%r" % (method.routing_key, json.loads(body)))
    ch.basic_ack(delivery_tag=method.delivery_tag)


@app.task
def message_receive():
    c = Customer("test_plat_topic", ["task.#"], callback)
    c.receive()


# celery  -A cmq worker --loglevel=info -B
if __name__ == '__main__':
    device_check()
