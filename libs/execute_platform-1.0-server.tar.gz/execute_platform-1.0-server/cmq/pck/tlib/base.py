import json
import unittest


class BaseCase(unittest.TestCase):
    """ TestCase classes that want to be parametrized should inherit from this class. 
    """

    def __init__(self, methodName='runTest', param=None):
        super(BaseCase, self).__init__(methodName)
        self.data_bases = {}
        self.appium_drivers = []
        self.urls = {}
        self.param = param

    @staticmethod
    def parametrize(testcase_klass, param=None):
        """ Create a suite containing all tests taken from the given
            subclass, passing them the parameter 'param'.
        """
        testloader = unittest.TestLoader()
        testnames = testloader.getTestCaseNames(testcase_klass)
        suite = unittest.TestSuite()
        for name in testnames:
            suite.addTest(testcase_klass(name, param=param))
        return suite

    def before(self):
        raise ("请重写before方法")

    def after(self):
        raise ("请重写after方法")

    def setUp(self):
        data = self.param
        if 'data_bases' in data.keys():
            self.data_bases = data['data_bases']
        if 'appium_drivers' in data.keys():
            self.appium_drivers = data['appium_drivers']
        if 'selenium_drivers' in data.keys():
            self.selenium_drivers = data['selenium_drivers']
        if 'urls' in data.keys():
            self.urls = data['urls']
        self.before()

def tearDown(self):
    self.after()
