import json
from enum import Enum

import requests

from cmq.pck.util import filelib


class Method(Enum):
    POST = 'post'
    GET = 'get'
    DELETE = 'delete'
    PUT = 'put'


class Http:
    def __init__(self, header=None, timeout=None, allow_redirects=False, verify=True):
        """
        初始化请求
        :param header: 请求头
        :param timeout: 超时时间
        :param allow_redirects: 是否重定向
        :param verify: https证书验证,false可以跳过证书验证，如果要验证：verify='/path-to/charles-ssl-proxying-certificate.pem'
        """
        self.session = requests.Session()
        self.timeout = timeout
        self.allow_redirects = allow_redirects
        self.headers = header
        self.cookies = None
        self.verify = verify

    def set_cookies(self, cookies=None):
        self.cookies = cookies

    def download(self, url, file_path, file_name):
        """
        下载
        :param url: 地址
        :param file_path: 文件夹路径
        :param file_name: 文件名
        :return:
        """
        filelib.create(file_path)
        path = file_path + '/' + file_name
        filelib.remove_file(path)
        response = self.session.get(url, stream=True)
        f = open(path, "wb")
        chunk_size = 1024  # 单次请求最大值
        content_size = int(response.headers['content-length'])  # 内容体总大小
        progress = ProgressBar(file_name, total=content_size,
                               unit="KB", chunk_size=chunk_size, run_status="正在下载", fin_status="下载完成")
        for data in response.iter_content(chunk_size=chunk_size):
            if data:
                f.write(data)
                progress.refresh(count=len(data))

    def upload(self, url, files):
        """
        :param url:
        :param files: {
                        "field1" : ("filename1", open("filePath1", "rb")),
                        "field2" : ("filename2", open("filePath2", "rb"), "image/jpeg"),
                        "field3" : ("filename3", open("filePath3", "rb"), "image/jpeg", {"refer" : "localhost"})
                        }
        :return:
        """
        self.session.post(url, files=files)

    def request(self, url="", data="", method=Method.GET):
        body = json.dumps(data)
        # print("url: " + url)
        # print("headers: " + str(self.headers))
        # print("method: " + str(method))
        # print("data: " + body)
        re = object
        is_except = False
        if method == Method.POST:
            re = self.session.post(url, headers=self.headers, data=body, timeout=self.timeout,
                                   allow_redirects=self.allow_redirects, cookies=self.cookies, verify=self.verify)

        elif method == Method.GET:
            re = self.session.get(url, headers=self.headers, timeout=self.timeout,
                                  allow_redirects=self.allow_redirects, cookies=self.cookies, verify=self.verify)

        elif method == Method.DELETE:
            re = self.session.delete(url, headers=self.headers, timeout=self.timeout,
                                     allow_redirects=self.allow_redirects, cookies=self.cookies, verify=self.verify)

        elif method == Method.PUT:
            re = self.session.put(url, data=body, headers=self.headers, timeout=self.timeout,
                                  allow_redirects=self.allow_redirects, cookies=self.cookies, verify=self.verify)
        try:
            result = re.json()
        except Exception as e:
            result = re
            is_except = True
        return {'is_except': is_except, 'result': result}

    def close(self):
        if self.session:
            self.session.close()


class ProgressBar(object):
    def __init__(self, title,
                 count=0.0,
                 run_status=None,
                 fin_status=None,
                 total=100.0,
                 unit='', sep='/',
                 chunk_size=1.0):
        super(ProgressBar, self).__init__()
        self.info = "【%s】%s %.2f %s %s %.2f %s"
        self.title = title
        self.total = total
        self.count = count
        self.chunk_size = chunk_size
        self.status = run_status or ""
        self.fin_status = fin_status or " " * len(self.status)
        self.unit = unit
        self.seq = sep

    def __get_info(self):
        # 【名称】状态 进度 单位 分割线 总数 单位
        _info = self.info % (self.title, self.status,
                             self.count / self.chunk_size, self.unit, self.seq, self.total / self.chunk_size, self.unit)
        return _info

    def refresh(self, count=1, status=None):
        self.count += count
        # if status is not None:
        self.status = status or self.status
        end_str = "\r"
        if self.count >= self.total:
            end_str = '\n'
            self.status = status or self.fin_status
        print(self.__get_info(), end=end_str)
