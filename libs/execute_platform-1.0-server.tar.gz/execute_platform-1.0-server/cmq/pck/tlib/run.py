import unittest

from cmq.util.importlib import dynamic_import_class

from cmq.pacakage.tlib.base import BaseCase


def run_case(case_dir, module_name, param):
    """
    运行case
    :param case_dir:用例文件夹路径
    :param module_name:模块名称
    :param param:环境数据
    :return:
    """
    modulep = case_dir + '.' + module_name
    class_name = module_name[0:1].upper() + module_name[1:]
    cls = dynamic_import_class(modulep, class_name)
    suite = unittest.TestSuite()
    suite.addTest(BaseCase.parametrize(cls, param=param))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return result
