from __future__ import absolute_import

from celery import Celery

app = Celery("execute_plat")
import sys

print(sys.path)

app.config_from_object('cmq.pck.celeryconfig')
