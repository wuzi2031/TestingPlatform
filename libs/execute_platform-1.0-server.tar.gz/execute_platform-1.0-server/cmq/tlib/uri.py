class Url:
    def __init__(self, obj):
        self.obj = obj

    def get_url(self, key):
        return self.obj.urls.get(key, None)


class Erp(Url):
    def address(self):
        return self.get_url("erp")


class Mind(Url):
    def address(self):
        return self.get_url("mind")
