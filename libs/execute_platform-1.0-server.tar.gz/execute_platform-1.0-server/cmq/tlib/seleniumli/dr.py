from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


class Selenium:
    def __init__(self, obj):
        self.selenium_drivers = obj.selenium_drivers

    def driver(self):
        sDriver = None
        for sd in self.selenium_drivers:
            if '_used' in sd.keys() and sd['_used']:
                continue
            else:
                sDriver = sd
                break
        host = sDriver['host']
        port = sDriver['port']

        self.driver = webdriver.Remote(
            command_executor='http://' + host + ':' + port + '/wd/hub',
            desired_capabilities=DesiredCapabilities.CHROME)
        return self.driver

    def quit_driver(self):
        self.driver.close()
