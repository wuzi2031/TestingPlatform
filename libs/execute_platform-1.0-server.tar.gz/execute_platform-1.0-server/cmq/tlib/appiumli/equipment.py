from appium import webdriver


class Android:
    def __init__(self, obj, equipment_name):
        equip_list = [driver for driver in obj.appium_drivers if equipment_name in driver.keys()]
        for e in equip_list:
            self.equipment = e
            self.equip = e[equipment_name]
            if '_used' in self.equip and self.equip['_used']:
                self.equip = None
                continue
            else:
                break
        self.device_name = self.equip['device_name']
        self.app_package = self.equip['app_package']
        self.app_activity = self.equip['app_activity']
        self.host = self.equip['host']
        self.port = self.equip['port']
        self.platform_version = self.equip['platform_version']

    def init_driver(self, device_name, app_package, app_activity, host='127.0.0.1', port='4723', platform_version=''):
        desired_caps = {
            'platformName': 'Android',
            'fastReset': 'false',
            'noReset': True,
            'platformVersion': platform_version,
            'deviceName': device_name,
            'appPackage': app_package,
            'appActivity': app_activity,
            'fullReset': 'false',
            # 'unicodeKeyboard': 'True',
            # 'resetKeyboard': 'True',
            # 'chromeOptions': {
            #     'androidProcess': 'com.tencent.mm:appbrand0'
            # }
        }
        self.driver = webdriver.Remote('http://' + host + ':' + port + '/wd/hub', desired_caps)

    def driver(self):
        self.init_driver(device_name=self.device_name, app_package=self.app_package, app_activity=self.app_activity,
                         host=self.host,
                         port=self.port, platform_version=self.platform_version)
        self.equip['_used'] = True
        self.equipment.update(self.equip)
        return self.driver

    def quit_driver(self):
        self.driver.close()


class DP700(Android):
    def __init__(self, obj):
        super().__init__(obj, 'dp700')


class HUAWEI_NOVA(Android):
    def __init__(self, obj):
        super().__init__(obj, 'huawei_nova')
