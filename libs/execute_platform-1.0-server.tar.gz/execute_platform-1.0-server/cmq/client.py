import json
import os
from multiprocessing import Process

from cmq import setting
from cmq.mq.mqclient import Customer
from cmq.tlib.request.httpRequests import Http, Method
from cmq.util.adb import AdbTools
from cmq.util.common import kill_process_by_name, gethost, kill_process_by_port


def run_celery():
    """
    开启定时任务
    :return:
    """
    path = os.getcwd()
    os.chdir(path)
    print(path)
    os.system("celery  -A cmq worker --loglevel=info -B")


def kill_celery():
    """
    退出定时任务
    :return:
    """
    kill_process_by_name('celery')


def run_mqclient():
    """
    开启mq监听
    :return:
    """
    c = Customer("test_plat_topic", ["task.#"], callback)
    c.receive()
    return c


def start_selenium_server(port='4444'):
    """
    启动selenium_server
    :param port:
    :return:
    """
    # java -jar selenium-server-standalone-3.12.0.jar -port 4444
    path = os.getcwd()
    os.chdir(path + "/jar")
    os.system("java -jar selenium-server-standalone-3.12.0.jar -port " + str(port))


def kill_selenium_server():
    kill_process_by_name("selenium-server-standalone")


# 记录appium已占用的端口
APPIUM_PORT = []


def gen_appium_port():
    """
    生成appium_port
    :return:
    """
    appium_port = 4723
    while appium_port in APPIUM_PORT:
        appium_port = appium_port + 1
    APPIUM_PORT.append(appium_port)
    return appium_port


def start_appium_server(deviceid='', appium_port=4723):
    """
    启动appium server
    :param address: 启动server的地址，如果不指定为0.0.0.0
    :param appium_port: 启动的server的端口号，默认4723
    :param bootstrap_port: 与高版本（4.2及以上）android机交互的端口号，默认3724
    :param selendroid_port: 与低版本（4.2以下）android机交互的端口号，默认8080
    :param chromedriver_port: 与chrome浏览器交互的端口号，默认9516
    :param deviceid: 设备的id
    :return:
    """
    address = gethost()['ip']
    # start_server_cmd = "nohup appium  --session-override -a " + address + " -p " + str(appium_port) + " -bp " \
    #                    + bootstrap_port + " --selendroid-port " + selendroid_port + " --chromedriver-port " + \
    #                    chromedriver_port + " -U " + deviceid + " --no-reset &"
    start_server_cmd = "nohup appium  --session-override -a " + address + " -p " + str(
        appium_port) + " -U " + deviceid + " --no-reset &"
    print(start_server_cmd)
    os.popen(start_server_cmd).readlines()


def stop_appium_server(appium_port=4723):
    """
    停止server
    :param appium_port:
    :return:
    """
    kill_process_by_port('appium', appium_port)
    if appium_port in APPIUM_PORT:
        APPIUM_PORT.remove(appium_port)


def download_apk(url, file_path, file_name):
    http = Http()
    http.download(url=url, file_path=file_path, file_name=file_name)


def callback(ch, method, properties, body):
    print(" [x] %r:%r" % (method.routing_key, json.loads(body)))
    ch.basic_ack(delivery_tag=method.delivery_tag)
    respons_dict = {}
    msg = json.loads(body)
    respons_dict['env_config'] = msg['env_config']
    host = gethost()['ip']
    adbTools = AdbTools()
    code_que = [device['code'] for device in adbTools.get_devices()['list']]
    option = msg['option']
    if option == 'start':
        webs = msg['webs']
        apps = msg['apps']
        servivce_list = []
        for web in webs:
            if web['host'] == host:
                port = 4444
                t = Process(target=start_selenium_server, args=(port,))
                t.start()
                servivce = {}
                servivce['type'] = 'selenium'
                servivce['host'] = host
                servivce['port'] = port
                servivce_list.append(servivce)
                break
        used_devices = []
        for app in apps:
            # 下载apk
            apk_path = app['app']
            apk_name = apk_path.split('/')[-1:][0]
            download_apk(setting.PLAT_URL + apk_path, setting.TEST_APK_PATH, apk_name)
            # 下载测试apk
            pass
            package_name = app['package_name']
            devices = app['devices']
            for device in devices:
                c = device['fields']['code']
                if c in code_que:
                    used_devices.append(json.dumps(device))
            for used_d in used_devices:
                used_device = json.loads(used_d)
                used_code = used_device['fields']['code']
                # 卸载apk
                adb_tool = AdbTools(used_code)
                adb_tool.uninstall(package_name)
                # 安装apk
                adb_tool.install(setting.TEST_APK_PATH + '/' + apk_name)
                # 启动appium远程服务端
                port = gen_appium_port()
                t = Process(target=start_appium_server, args=(used_code, port))
                t.start()
                servivce = {}
                servivce['type'] = 'appium'
                servivce['host'] = host
                servivce['port'] = port
                servivce['device_name'] = used_device['fields']['name']
                servivce['device_code'] = used_code
                servivce_list.append(servivce)
        respons_dict['servivce_list'] = servivce_list
        # 接口通知服务端
        print('通知设备信息...')
        print(respons_dict)
        http = Http(header={'Content-Type': 'application/json'})
        http.request(url=setting.PLAT_URL + "/client_ready", data=respons_dict, method=Method.POST)

    elif option == 'stop' or option == 'finish':
        # 停止
        selenium_list = msg['selenium_drivers']
        if selenium_list:
            for selenium in selenium_list:
                if selenium['host'] == host:
                    kill_selenium_server()
                    break
        appium_list = msg['appium_drivers']
        if appium_list:
            for appium in appium_list:
                for key, value in appium.items():
                    if value['host'] == host and value['device_name'] in code_que:
                        port = value['port']
                        stop_appium_server(port)
                        APPIUM_PORT.remove(port)
        respons_dict['host'] = host
        http = Http(header={'Content-Type': 'application/json'})
        http.request(url=setting.PLAT_URL + "/client_env_clear", data=respons_dict, method=Method.POST)


def start():
    process = Process(target=run_mqclient)
    process.start()
    run_celery()


def stop():
    kill_process_by_name('appium')
    kill_selenium_server()
    kill_celery()


if __name__ == "__main__":
    import sys
    print(sys.path)
    # start之前需设置setting里面值
    # 测试服务器
    setting.PLAT_URL = 'http://127.0.0.1:8000'
    # 测试apk下载路径
    setting.TEST_APK_PATH = '/Users/Shared/apk'
    # mq配置
    setting.BROKER_CONFIG = {
        "address": "120.79.16.35",
        "port": 5672,
        "user": "admin",
        "password": "admin",
    }
    # 开启服务
    start()
