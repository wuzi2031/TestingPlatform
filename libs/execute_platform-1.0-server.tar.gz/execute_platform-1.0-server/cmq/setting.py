import os
import sys

from cmq.util import importlib

if os.getcwd() not in sys.path:
    sys.path.append(os.getcwd())
mod = "setting"
m = importlib.dynamic_import_module(mod)
# 测试服务器
PLAT_URL = m.PLAT_URL
# 测试apk下载路径
TEST_APK_PATH = m.TEST_APK_PATH
# mq配置
BROKER_CONFIG = m.BROKER_CONFIG
