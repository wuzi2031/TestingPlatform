# from __future__ import absolute_import
#
# from celery import Celery
#
# app = Celery("execute_plat")
# app.config_from_object("cmq.celeryconfig")

# server端的包需注释本文件
