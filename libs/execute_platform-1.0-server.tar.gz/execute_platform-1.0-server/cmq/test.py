from cmq.tasks import message_receive

message_receive.delay()
