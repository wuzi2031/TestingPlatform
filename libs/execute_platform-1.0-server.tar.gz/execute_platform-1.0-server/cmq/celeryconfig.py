from __future__ import absolute_import

from datetime import timedelta

from cmq.setting import BROKER_CONFIG

BROKER_URL = 'amqp://' + BROKER_CONFIG['user'] + ':' + BROKER_CONFIG['password'] + '@' + BROKER_CONFIG[
    'address'] + ':' + str(BROKER_CONFIG['port']) + '//'

CELERY_TIMEZONE = "Asia/Shanghai"
CELERY_IMPORTS = (
    "cmq.tasks",
)

CELERYBEAT_SCHEDULE = {
    "get_proxy_30_sec": {
        "task": "cmq.tasks.device_check",
        "schedule": timedelta(seconds=30),
        # "schedule": crontab(minute="*/20"),
        "args": ()
    },
    # "check_proxy_10_min": {
    #     "task": "celery_task.obtain_data_task.check_proxy",
    #     "schedule": timedelta(minutes=11),
    #     # "schedule": crontab(minute="*/11"),
    #     "args": ()
    # },
    # "generate_model_day": {
    #     "task": "celery_task.obtain_model_task.generate_model",
    #     "schedule": timedelta(hours=100),
    #     # "schedule": crontab(day_of_month="2-29/5"),
    #     "args": ()
    # },

}
