from cmq.db.database import TradeDataBase
from cmq.tlib.appiumli.equipment import DP700
from cmq.tlib.base import BaseCase
from cmq.tlib.seleniumli.dr import Selenium
from cmq.tlib.uri import Erp, Mind


class TestUi(BaseCase):
    # 本地调试脚本，环境数据放在跟脚本相同目录下的env_setting.py里。
    # 注意：脚本上传服务器前必须改成DEBUG = False
    DEBUG = True

    def before(self):
        self.dp700 = DP700(self)
        self.driver = self.dp700.driver()
        # self.dp7001 = DP700(self)
        self.selenium = Selenium(self)
        self.selenium_driver = self.selenium.driver()
        pass

    def test_qq_login(self):
        print('test_qq_login')
        # sleep(3)
        # exc = Executer(self, 'trade')
        # re = exc.execute("select * from case_caseset WHERE id=%s OR id=%s", (3, 4), return_one=True)
        # print(re)
        # self.assertEqual(True, False)
        re = TradeDataBase.execute(self, "select * from case_case WHERE id=%s", (1,), return_one=True)
        print(re)
        erp_url = Erp(self).address()
        print(erp_url)
        mind_url = Mind(self).address()
        print(mind_url)

    def after(self):
        # self.dp700.quit_driver()
        self.selenium.quit_driver()
        pass
