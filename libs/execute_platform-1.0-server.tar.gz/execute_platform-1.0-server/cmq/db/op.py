import threading

from cmq.db.pymysql_pool import ConnectionPool


class Executer:
    _instance_lock = threading.Lock()
    __first_init = True
    __data_base = {}

    def __new__(cls, obj, data_base='default'):
        if data_base not in cls.__data_base.keys():
            with Executer._instance_lock:
                cls.__data_base[data_base] = object.__new__(cls)
        return cls.__data_base[data_base]

    def __init__(self, obj, data_base='default'):
        if self.__first_init:
            data_base_config = obj.data_bases[data_base]
            config = {'host': data_base_config['HOST'], 'user': data_base_config['USER'],
                      'password': data_base_config['PASSWORD'],
                      'database': data_base_config['NAME']}
            self.pool = ConnectionPool(size=3, name='pool', **config)
            self.__first_init = False

    def execute(self, sql, args=(), return_one=False):
        """
        执行sql
        :param sql:sql语句
        :param args:参数
        :param return_one:返回一个
        :return:
        """
        con = self.pool.get_connection()
        result = con.execute_query(query=sql, args=args, return_one=return_one, dictcursor=True)
        return result


if __name__ == "__main__":
    execu = Executer()
    re = execu.exc("select * from case_caseset WHERE id=%s OR id=%s", (3, 4), return_one=True)
    print(re['add_time'])
    execu2 = Executer()
    execu2.exc("update case_caseset set NAME ='用例集' WHERE id=%s", (3,))
    print(re)
    execu1 = Executer(data_base='data1')
    re1 = execu1.exc("select * from case_caseset WHERE id=%s OR id=%s", (3, 4))
    print(re1)
