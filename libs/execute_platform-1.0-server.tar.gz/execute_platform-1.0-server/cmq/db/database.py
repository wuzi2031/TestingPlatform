from cmq.db.op import Executer


class TradeDataBase:
    @classmethod
    def execute(cls, obj, sql, args=(), return_one=False):
        executer = Executer(obj, 'trade')
        return executer.execute(sql, args, return_one)


class NotTradeDataBase:
    @classmethod
    def execute(cls, obj, sql, args=(), return_one=False):
        executer = Executer(obj, 'not_trade')
        return executer.execute(sql, args, return_one)
